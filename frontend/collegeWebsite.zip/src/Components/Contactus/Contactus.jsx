import React from "react";
import "./Contactus.css";
import mail from "../../../assets/mail3.jpg";
import mail2 from "../../../assets/mail.png";
import phone from "../../../assets/phone.png";
import location from "../../../assets/location.png";
import whiteArrow from "../../../assets/white-arrow.png";
function Contactus() {
  const [result, setResult] = React.useState("");

  const onSubmit = async (event) => {
    event.preventDefault();
    setResult("Sending....");
    const formData = new FormData(event.target);

    formData.append("access_key", "9e908df8-406b-484b-8e70-a74e84174002");

    const response = await fetch("https://api.web3forms.com/submit", {
      method: "POST",
      body: formData,
    });

    const data = await response.json();

    if (data.success) {
      setResult("Form Submitted Successfully");
      event.target.reset();
    } else {
      console.log("Error", data);
      setResult(data.message);
    }
  };

  return (
    <>
      <div className="contactus">
        <div className="contactCol">
          <h3>
            reach us out <img src={mail}></img>{" "}
          </h3>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum
            in urna sit amet diam viverra tempus. Fusce volutpat lacus nec
            sapien fringilla consectetur. Quisque aliquet velit non nisi gravida
            vestibulum. In et semper metus. Morbi nec libero eget ex tincidunt
            fringilla nec nec odio. Vivamus malesuada, odio non ultrices
            molestie, elit leo efficitur nunc, eu suscipit nisi libero id sem.
            Proin vehicula, neque sit amet rutrum varius, metus nulla facilisis
            magna,{" "}
          </p>
          <ul>
            <li>
              <img src={mail2}></img>contact mail
            </li>
            <li>
              <img src={phone}></img>phone number
            </li>
            <li>
              <img src={location}></img>address of institution
            </li>
          </ul>
        </div>
        <div className="contactCol">
          <form onSubmit={onSubmit}>
            <label>Your name</label>
            <input
              type="text"
              name="name"
              placeholder="Enter your name :"
              required
            ></input>
            <label>Phone Number</label>
            <input
              type="tel"
              name="phone"
              placeholder="Enter your mobile number"
              required
            ></input>
            <label>Write your messsages here</label>
            <textarea
              name="message"
              rows="6"
              placeholder="Enter your message"
              required
            ></textarea>
            <button type="submit" className="btn darkBtn">
              Submit now <img src={whiteArrow}></img>
            </button>
          </form>
          <span>{result}</span>
        </div>
      </div>
    </>
  );
}

export default Contactus;
