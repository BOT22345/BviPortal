import './Footer.css';

function Footer(){
  return<>
  <div className="footer">
  <p>c 2024 bvicam, All rights reserverd</p>
    <ul>
      <li>terms of service</li>
      <li>privacy policy</li>
    </ul>
  </div>
  </>
}
export default Footer;